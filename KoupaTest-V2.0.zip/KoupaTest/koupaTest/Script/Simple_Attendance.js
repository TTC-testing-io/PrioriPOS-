﻿
var KeyActions = require("KeyActions");

function CheckIn(){
  
}


function CheckOut(){
  
}